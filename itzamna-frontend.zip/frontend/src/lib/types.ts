export type PlanetId = 'luna' | 'marte';

export interface FieldOption {
  value: string;
  label: string;
}

export interface FieldDef {
  id: string;
  label: string;
  options: FieldOption[];
}

export interface PlanetDef {
  id: PlanetId;
  name: string;
  fields: FieldDef[];
}

/** Campo de información: `value` va en la vista general, `detail` en la avanzada. */
export interface InfoField {
  label: string;
  value: string;
  detail: string;
}

export interface BodyInfo {
  kicker: string;
  title: string;
  /** Fondo CSS del marcador de imagen hasta que existan imágenes reales. */
  tone: string;
  fields: InfoField[];
}

export interface Match {
  id: string;
  percentage: number;
  earth: BodyInfo;
  zone: BodyInfo;
}

export interface SearchQuery {
  planet: PlanetId;
  /** id de campo -> valor elegido. Los campos vacíos no se envían. */
  earth: Record<string, string>;
  zone: Record<string, string>;
}
