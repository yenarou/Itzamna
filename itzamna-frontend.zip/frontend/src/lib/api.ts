import { ANALOGS } from './data';
import type { Match, SearchQuery } from './types';

const API_URL: string = import.meta.env.PUBLIC_API_URL ?? '';

/**
 * Busca zonas de la Tierra análogas a una zona de la Luna o Marte.
 *
 * Con PUBLIC_API_URL definida intenta llamar al backend. La ruta es provisional:
 * ajústala cuando el backend defina el contrato. Si falla o no hay URL,
 * se usan los datos de ejemplo de data.ts.
 */
export async function searchAnalogs(query: SearchQuery): Promise<Match[]> {
  if (API_URL) {
    try {
      const res = await fetch(`${API_URL}/api/analogs/search`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(query),
      });
      if (res.ok) return (await res.json()) as Match[];
    } catch {
      /* se usa el respaldo local */
    }
  }
  return mockSearch(query);
}

async function mockSearch(query: SearchQuery): Promise<Match[]> {
  await new Promise((resolve) => setTimeout(resolve, 600));

  const earthEntries = Object.entries(query.earth);
  const zoneEntries = Object.entries(query.zone);
  const total = earthEntries.length + zoneEntries.length;

  return ANALOGS.filter((a) => a.planet === query.planet)
    .map((a) => {
      const hits =
        earthEntries.filter(([k, v]) => a.earthTags[k] === v).length +
        zoneEntries.filter(([k, v]) => a.zoneTags[k] === v).length;
      const percentage = Math.max(15, Math.min(99, a.base - 9 * (total - hits)));
      return { id: a.id, percentage, earth: a.earth, zone: a.zone } satisfies Match;
    })
    .sort((a, b) => b.percentage - a.percentage);
}
