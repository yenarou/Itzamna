import { searchAnalogs } from '../lib/api';
import type { BodyInfo, Match, PlanetId, SearchQuery } from '../lib/types';

type State = 'idle' | 'selected' | 'searching' | 'results';

function el<T extends Element>(selector: string): T {
  const found = document.querySelector<T>(selector);
  if (!found) throw new Error(`Falta el elemento ${selector}`);
  return found;
}

const root = el<HTMLElement>('#explorer');
const planetSelect = el<HTMLSelectElement>('#planet-select');
const emptyPrompt = el<HTMLElement>('#empty-prompt');
const control = el<HTMLElement>('#control');
const toggleSearch = el<HTMLButtonElement>('#toggle-search');
const chevron = el<SVGSVGElement>('#chevron');
const percentValue = el<HTMLElement>('#percent-value');
const searchPanel = el<HTMLFormElement>('#search-panel');
const confirmBtn = el<HTMLButtonElement>('#confirm');
const searchStatus = el<HTMLElement>('#search-status');
const results = el<HTMLElement>('#results');
const resultsClose = el<HTMLButtonElement>('#results-close');
const matchTabs = el<HTMLElement>('#match-tabs');
const resultPercent = el<HTMLElement>('#result-percent');
const general = el<HTMLElement>('#general');
const advancedToggle = el<HTMLButtonElement>('#advanced-toggle');
const advanced = el<HTMLElement>('#advanced');

let planet: PlanetId | '' = '';
let matches: Match[] = [];
let active = 0;

function esc(text: string): string {
  return text.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
}

function setState(next: State): void {
  root.dataset.state = next;
  searchPanel.hidden = next !== 'searching';
  results.hidden = next !== 'results';
  control.hidden = next === 'results';
  toggleSearch.disabled = next === 'idle';
  toggleSearch.setAttribute('aria-expanded', String(next === 'searching'));
  chevron.style.transform = next === 'searching' ? 'rotate(180deg)' : '';
  emptyPrompt.hidden = next !== 'idle';
  if (next === 'results') results.scrollTo({ top: 0 });
}

function showPlanet(id: PlanetId | ''): void {
  document.querySelectorAll<HTMLElement>('[data-planet-view]').forEach((n) => {
    n.hidden = n.dataset.planetView !== id;
  });
  document.querySelectorAll<HTMLElement>('[data-planet-fields]').forEach((n) => {
    n.hidden = n.dataset.planetFields !== id;
  });
}

function readGroup(group: 'earth' | 'zone'): Record<string, string> {
  const out: Record<string, string> = {};
  const fieldsets = searchPanel.querySelectorAll<HTMLFieldSetElement>(`fieldset[data-group="${group}"]`);
  fieldsets.forEach((fs) => {
    if (fs.hidden) return;
    fs.querySelectorAll<HTMLSelectElement>('select').forEach((s) => {
      if (s.value) out[s.name] = s.value;
    });
  });
  return out;
}

function bodyColumn(b: BodyInfo, withImage: boolean, longText: boolean): string {
  const fields = b.fields
    .map((f) =>
      longText
        ? `<div class="border-t border-line py-4">
             <dt class="text-sm text-mist">${esc(f.label)}</dt>
             <dd class="mt-1 font-medium">${esc(f.value)}</dd>
             <dd class="mt-2 max-w-[60ch] leading-relaxed text-mist">${esc(f.detail)}</dd>
           </div>`
        : `<div class="rounded-md border border-line bg-panel px-4 py-3">
             <dt class="text-sm text-mist">${esc(f.label)}</dt>
             <dd class="mt-0.5 font-medium">${esc(f.value)}</dd>
           </div>`,
    )
    .join('');
  const image = withImage
    ? `<div class="img-slot" style="background:${b.tone}" role="img" aria-label="Imagen de referencia: ${esc(b.title)}"></div>`
    : '';
  return `<article class="space-y-4">
      <header>
        <p class="text-sm text-mist">${esc(b.kicker)}</p>
        <h3 class="font-display text-2xl font-medium">${esc(b.title)}</h3>
      </header>
      ${image}
      <dl class="${longText ? '' : 'space-y-3'}">${fields}</dl>
    </article>`;
}

function renderResults(): void {
  const m = matches[active];
  if (!m) return;

  matchTabs.innerHTML = matches
    .map(
      (x, i) =>
        `<button type="button" role="tab" data-i="${i}" aria-selected="${i === active}"
           class="rounded-md border px-3 py-1.5 text-sm ${
             i === active ? 'border-ochre bg-deep text-chalk' : 'border-line text-mist hover:text-chalk'
           }">${esc(x.earth.title)} <span class="text-ochre">${x.percentage}%</span></button>`,
    )
    .join('');

  resultPercent.textContent = `${m.percentage}%`;
  general.innerHTML = bodyColumn(m.earth, true, false) + bodyColumn(m.zone, true, false);
  advanced.innerHTML = bodyColumn(m.earth, false, true) + bodyColumn(m.zone, false, true);
}

/* ----- Eventos ----- */

planetSelect.addEventListener('change', () => {
  planet = planetSelect.value as PlanetId | '';
  matches = [];
  percentValue.textContent = '—';
  searchStatus.textContent = '';
  showPlanet(planet);
  setState(planet ? 'selected' : 'idle');
});

toggleSearch.addEventListener('click', () => {
  setState(root.dataset.state === 'searching' ? 'selected' : 'searching');
});

searchPanel.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!planet) return;

  const query: SearchQuery = { planet, earth: readGroup('earth'), zone: readGroup('zone') };
  confirmBtn.disabled = true;
  searchStatus.textContent = 'Buscando zonas similares…';

  try {
    matches = await searchAnalogs(query);
    active = 0;
    if (matches.length === 0) {
      searchStatus.textContent = 'No hay zonas con esas características. Prueba con menos filtros.';
      return;
    }
    searchStatus.textContent = '';
    percentValue.textContent = `${matches[0].percentage}%`;
    advanced.hidden = true;
    advancedToggle.setAttribute('aria-expanded', 'false');
    advancedToggle.textContent = 'Ver información avanzada';
    renderResults();
    setState('results');
  } catch {
    searchStatus.textContent = 'No se pudo completar la búsqueda. Inténtalo de nuevo.';
  } finally {
    confirmBtn.disabled = false;
  }
});

matchTabs.addEventListener('click', (event) => {
  const tab = (event.target as HTMLElement).closest<HTMLElement>('[data-i]');
  if (!tab) return;
  active = Number(tab.dataset.i);
  renderResults();
});

advancedToggle.addEventListener('click', () => {
  const open = advanced.hidden;
  advanced.hidden = !open;
  advancedToggle.setAttribute('aria-expanded', String(open));
  advancedToggle.textContent = open ? 'Ocultar información avanzada' : 'Ver información avanzada';
});

resultsClose.addEventListener('click', () => setState('selected'));

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  const state = root.dataset.state;
  if (state === 'searching' || state === 'results') setState('selected');
});

setState('idle');
